let medicines = [];

// Load medicines from file
async function loadMedicines() {
    showLoading();
    console.log('Starting to load medicines...');
    
    try {
        // Clear localStorage to force reload from file - FOR DEBUGGING
        // localStorage.removeItem('medicines');
        
        // Try to load from localStorage first
        const savedMedicines = localStorage.getItem('medicines');
        if (savedMedicines) {
            try {
                console.log('Found medicines in localStorage');
                medicines = JSON.parse(savedMedicines);
                console.log(`Loaded ${medicines.length} medicines from localStorage`);
                if (Array.isArray(medicines) && medicines.length > 0) {
                    hideLoading();
                    return true;
                }
            } catch (e) {
                console.error('Error parsing localStorage data:', e);
                // Clear invalid data
                localStorage.removeItem('medicines');
            }
        }

        // If not in localStorage or invalid data, load from medicines.txt
        console.log('Loading medicines from file...');
        try {
            const response = await fetch('medicines.txt?t=' + new Date().getTime()); // Add timestamp to prevent caching
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const text = await response.text();
            console.log('Raw file content:', text.substring(0, 200) + '...'); // Log first 200 chars
            
            if (!text.trim()) {
                throw new Error('Empty file');
            }
            
            const lines = text.trim().split('\n');
            console.log(`Found ${lines.length} lines in file`);
            
            // Process each line and filter out any invalid entries
            const validMedicines = [];
            const invalidLines = [];
            
            lines.forEach((line, index) => {
                try {
                    const [name, quantity, expiryDate, manufacturer, price] = line.split(',');
                    if (!name || !name.trim()) {
                        invalidLines.push(`Line ${index + 1}: Missing medicine name`);
                        return;
                    }
                    
                    const med = {
                        name: name.trim(),
                        quantity: parseInt(quantity) || 0,
                        expiryDate: (expiryDate || '').trim(),
                        manufacturer: (manufacturer || '').trim(),
                        price: parseFloat(price) || 0.0
                    };
                    
                    if (med.quantity < 0 || isNaN(med.quantity)) {
                        invalidLines.push(`Line ${index + 1}: Invalid quantity`);
                        return;
                    }
                    
                    if (med.price < 0 || isNaN(med.price)) {
                        invalidLines.push(`Line ${index + 1}: Invalid price`);
                        return;
                    }
                    
                    validMedicines.push(med);
                } catch (e) {
                    console.error(`Error processing line ${index + 1}:`, e);
                    invalidLines.push(`Line ${index + 1}: ${e.message}`);
                }
            });
            
            console.log(`Successfully parsed ${validMedicines.length} valid medicines`);
            if (invalidLines.length > 0) {
                console.warn('Invalid lines found:', invalidLines);
            }
            
            if (validMedicines.length === 0) {
                throw new Error('No valid medicines found in file');
            }
            
            medicines = validMedicines;

            // Save to localStorage for future use
            localStorage.setItem('medicines', JSON.stringify(medicines));
            console.log(`Saved ${medicines.length} medicines to localStorage`);
            hideLoading();
            
            if (invalidLines.length > 0) {
                showError(`
                    <div class="alert alert-warning">
                        <h5 class="alert-heading">Data Loading Notice</h5>
                        <p>Loaded ${validMedicines.length} valid medicines, but found ${invalidLines.length} invalid entries.</p>
                        <p class="mb-0 small">${invalidLines.slice(0, 5).join('<br>')}${invalidLines.length > 5 ? '<br>...and ' + (invalidLines.length - 5) + ' more' : ''}</p>
                    </div>
                `);
            }
            
            return true;
            
        } catch (error) {
            console.error('Error loading from file:', error);
            throw new Error(`Could not load medicines from file: ${error.message}`);
        }
    } catch (error) {
        console.error('Error in loadMedicines:', error);
        
        // If everything fails, use hardcoded data as last resort
        medicines = [
            { name: "Paracetamol", quantity: 100, expiryDate: "2025-08-15", manufacturer: "Johnson & Johnson", price: 15.00 },
            { name: "Ibuprofen", quantity: 75, expiryDate: "2025-09-20", manufacturer: "Pfizer", price: 20.00 },
            { name: "Amoxicillin", quantity: 50, expiryDate: "2025-10-10", manufacturer: "GSK", price: 50.00 },
            { name: "Metformin", quantity: 120, expiryDate: "2025-11-30", manufacturer: "Sun Pharma", price: 30.00 }
        ];
        
        try {
            localStorage.setItem('medicines', JSON.stringify(medicines));
        } catch (e) {
            console.error('Error saving to localStorage:', e);
        }
        
        hideLoading();
        
        showError(`
            <div class="alert alert-warning">
                <h5 class="alert-heading">Data Loading Error</h5>
                <p class="mb-2">Could not load medicines from file: ${error.message}</p>
                <p class="mb-0">Using fallback data with limited medicines. Please check the console for details.</p>
            </div>
        `);
        
        return true;
    }
}

// Show loading modal
function showLoading() {
    $('#loadingState').removeClass('d-none');
    setTimeout(() => {
        $('#loadingState').addClass('fade-in');
    }, 100);
}

function hideLoading() {
    $('#loadingState').removeClass('fade-in');
    setTimeout(() => {
        $('#loadingState').addClass('d-none');
    }, 300);
}

// Show different sections
function showSection(section) {
    if (!medicines || medicines.length === 0) {
        showError(`
            <div class="alert alert-warning">
                <h5 class="alert-heading">No Medicines Available</h5>
                <p class="mb-2">Please add some medicines first.</p>
                <p class="mb-0">Click "Add Medicine" to get started.</p>
            </div>
        `);
        return;
    }

    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = '';

    switch (section) {
        case 'add':
            showAddForm();
            break;
        case 'search':
            showSearchForm();
            break;
        case 'display':
            showMedicineList();
            break;
        case 'edit':
            showEditForm();
            break;
        case 'low-stock':
            showLowStock();
            break;
        case 'expiry':
            showExpiryCheck();
            break;
        default:
            showMedicineList();
    }
}

// Initialize the app
function initializeApp() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Add click event for download button
    const downloadBtn = document.getElementById('downloadBtn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function(e) {
            e.preventDefault();
            downloadMedicinesList();
        });
    }

    // Show the default section
    showSection('display');
}

// Show message to user (works for both errors and success messages)
function showError(message, isSuccess = false) {
    const container = document.getElementById('contentArea');
    if (!container) return;
    
    // Create message element with improved styling
    const messageEl = document.createElement('div');
    messageEl.className = `alert-message ${isSuccess ? 'alert-success' : 'alert-danger'}`;
    
    // Add icon based on message type
    const icon = isSuccess ? 'check-circle' : 'exclamation-circle';
    messageEl.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-${icon} me-3" style="font-size: 1.5rem;"></i>
            <div>${message}</div>
        </div>
        <button type="button" class="btn-close" onclick="this.closest('.alert-message').remove()">
            <span class="visually-hidden">Close</span>
        </button>
    `;
    
    // Add close button functionality
    const closeBtn = messageEl.querySelector('.btn-close');
    closeBtn.addEventListener('click', () => {
        messageEl.style.opacity = '0';
        setTimeout(() => messageEl.remove(), 300);
    });
    
    // Insert at the top of the container
    container.insertBefore(messageEl, container.firstChild);
    
    // Auto-hide after 5 seconds with fade out animation
    const autoHide = setTimeout(() => {
        messageEl.style.opacity = '0';
        setTimeout(() => messageEl.remove(), 300);
    }, 5000);
    
    // Clear timeout if user hovers over the message
    messageEl.addEventListener('mouseenter', () => clearTimeout(autoHide));
    messageEl.addEventListener('mouseleave', () => {
        setTimeout(() => {
            messageEl.style.opacity = '0';
            setTimeout(() => messageEl.remove(), 300);
        }, 3000);
    });
}

// Function to download medicines list
function downloadMedicinesList() {
    if (!medicines || medicines.length === 0) {
        showError('No medicines available to download');
        return;
    }

    // Format the current date for the filename
    const today = new Date();
    const dateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    
    // Create a nicely formatted text
    let formattedText = `MEDICINE INVENTORY - ${dateStr}\n`;
    formattedText += '='.repeat(50) + '\n\n';
    
    // Add each medicine with formatting
    medicines.forEach((med, index) => {
        formattedText += `[${index + 1}] ${med.name.toUpperCase()}\n`;
        formattedText += `- Quantity: ${med.quantity}\n`;
        formattedText += `- Expiry: ${med.expiryDate}\n`;
        formattedText += `- Manufacturer: ${med.manufacturer}\n`;
        formattedText += `- Price: ₹${med.price.toFixed(2)}\n`;
        formattedText += '-'.repeat(50) + '\n\n';
    });
    
    // Add summary
    formattedText += `\nTOTAL MEDICINES: ${medicines.length}\n`;
    formattedText += `GENERATED ON: ${new Date().toLocaleString()}\n`;

    // Create a Blob with the text
    const blob = new Blob([formattedText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    // Create a temporary link and trigger download
    const a = document.createElement('a');
    a.href = url;
    a.download = `medicine_inventory_${dateStr}.txt`;
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    setTimeout(() => {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }, 100);
}

// Utility function to show loading state with improved visual feedback
function showLoading(button, duration = 0) {
    if (!button) return () => {}; // Return a no-op function if no button provided
    
    // Store original state
    const originalHTML = button.innerHTML;
    const originalWidth = button.offsetWidth;
    const originalHeight = button.offsetHeight;
    
    // Set fixed dimensions to prevent button from resizing
    button.style.width = `${originalWidth}px`;
    button.style.height = `${originalHeight}px`;
    
    // Create loading state
    button.innerHTML = `
        <div class="d-flex align-items-center justify-content-center w-100 h-100">
            <div class="spinner-border spinner-border-sm me-2" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <span class="btn-text">${button.textContent.trim()}</span>
        </div>
    `;
    
    // Add loading class for additional styling
    button.classList.add('btn-loading');
    
    // Disable button
    button.disabled = true;
    
    // Auto-hide after duration if specified
    let timeoutId;
    if (duration > 0) {
        timeoutId = setTimeout(() => {
            hideLoading(button);
        }, duration);
    }
    
    // Return cleanup function
    return () => {
        if (timeoutId) clearTimeout(timeoutId);
        hideLoading(button, originalHTML);
    };
}

// Utility function to hide loading state
function hideLoading(button, originalHTML) {
    if (!button) return;
    
    // Remove loading class
    button.classList.remove('btn-loading');
    
    // Restore original content
    if (originalHTML) {
        button.innerHTML = originalHTML;
    } else if (button.dataset.originalContent) {
        button.innerHTML = button.dataset.originalContent;
    }
    
    // Reset styles
    button.style.width = '';
    button.style.height = '';
    
    // Re-enable button
    button.disabled = false;
}

// Helper function to show form loading state
function showFormLoading(form, show = true) {
    if (!form) return;
    
    if (show) {
        // Add loading overlay
        if (!form.querySelector('.form-loading-overlay')) {
            const overlay = document.createElement('div');
            overlay.className = 'form-loading-overlay';
            overlay.innerHTML = `
                <div class="d-flex flex-column align-items-center justify-content-center h-100">
                    <div class="spinner-border text-primary mb-2" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="small text-muted">Processing...</div>
                </div>
            `;
            form.style.position = 'relative';
            form.appendChild(overlay);
        }
        
        // Disable all form controls
        const controls = form.querySelectorAll('input, select, textarea, button');
        controls.forEach(control => {
            control.disabled = true;
        });
    } else {
        // Remove loading overlay
        const overlay = form.querySelector('.form-loading-overlay');
        if (overlay) {
            overlay.remove();
        }
        
        // Re-enable all form controls
        const controls = form.querySelectorAll('input, select, textarea, button');
        controls.forEach(control => {
            control.disabled = false;
        });
    }
}

// Start the app
document.addEventListener('DOMContentLoaded', function() {
    // Check if localStorage is available
    try {
        localStorage.setItem('test', 'test');
        localStorage.removeItem('test');
        
        // Load medicines and initialize app
        loadMedicines().then(() => {
            initializeApp();
        }).catch(error => {
            console.error('App initialization error:', error);
            showError(`
                <div class="alert alert-danger">
                    <h5 class="alert-heading">App Initialization Error</h5>
                    <p class="mb-2">Failed to initialize the application.</p>
                    <p class="mb-0">${error.message || 'Please try refreshing the page.'}</p>
                </div>
            `);
        });
    } catch (e) {
        showError('Error: Your browser does not support localStorage. Some features may not work.');
    }
});

// Display Medicine List
function showMedicineList() {
    const container = document.getElementById('content-area');
    container.innerHTML = `
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Medicine Inventory</h4>
            </div>
            <div class="card-body">
                <div id="medicineList"></div>
            </div>
        </div>
    `;
    displayMedicines(medicines, 'medicineList');
}

// Display Medicines
function displayMedicines(medicines, targetId) {
    const container = document.getElementById(targetId);
    if (!container) return;

    // Add a scrollable container with fixed height
    container.style.maxHeight = '70vh';
    container.style.overflowY = 'auto';
    container.style.paddingRight = '10px';

    // Add a counter to show total medicines
    const counter = document.createElement('div');
    counter.className = 'mb-3 text-muted';
    counter.textContent = `Showing ${medicines.length} medicines`;
    container.innerHTML = '';
    container.appendChild(counter);

    // Create a row with columns for grid layout
    const row = document.createElement('div');
    row.className = 'row g-3';
    container.appendChild(row);

    // Add each medicine as a card in the grid
    medicines.forEach(medicine => {
        const col = document.createElement('div');
        col.className = 'col-12 col-md-6 col-lg-4';
        col.innerHTML = `
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">${medicine.name}</h5>
                    <div class="card-text">
                        <p class="mb-1"><strong>Quantity:</strong> ${medicine.quantity}</p>
                        <p class="mb-1"><strong>Expiry:</strong> ${medicine.expiryDate}</p>
                        <p class="mb-1"><strong>Manufacturer:</strong> ${medicine.manufacturer}</p>
                        <p class="mb-0"><strong>Price:</strong> ₹${medicine.price.toFixed(2)}</p>
                    </div>
                </div>
            </div>`;
        row.appendChild(col);
    });
}

// Show Low Stock
function showLowStock() {
    const container = document.getElementById('content-area');
    container.innerHTML = `
        <div class="card mb-4">
            <div class="card-header bg-warning">
                <h4 class="mb-0">Check Low Stock</h4>
            </div>
            <div class="card-body">
                <div class="row g-3 align-items-end">
                    <div class="col-md-6">
                        <label for="lowStockThreshold" class="form-label">Show medicines with quantity less than or equal to:</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="lowStockThreshold" value="10" min="1">
                            <button class="btn btn-primary" onclick="checkLowStock()">Check</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-warning">
                <h4 class="mb-0">Low Stock Medicines</h4>
            </div>
            <div class="card-body">
                <div id="lowStockList">
                    <div class="text-muted text-center py-4">
                        <i class="fas fa-search fa-2x mb-2"></i>
                        <p>Enter a quantity and click 'Check' to find low stock items</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Show Expiry Check
function showExpiryCheck() {
    const container = document.getElementById('content-area');
    container.innerHTML = `
        <div class="card mb-4">
            <div class="card-header bg-danger text-white">
                <h4 class="mb-0">Check Expiring Medicines</h4>
            </div>
            <div class="card-body">
                <div class="row g-3 align-items-end">
                    <div class="col-md-6">
                        <label for="expiryDateInput" class="form-label">Show medicines expiring before:</label>
                        <div class="input-group">
                            <input type="date" class="form-control" id="expiryDateInput">
                            <button class="btn btn-danger" onclick="checkExpiry()">Check</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h4 class="mb-0">Expired/Expiring Medicines</h4>
            </div>
            <div class="card-body">
                <div id="expiryList">
                    <div class="text-muted text-center py-4">
                        <i class="fas fa-calendar-alt fa-2x mb-2"></i>
                        <p>Select a date and click 'Check' to find expiring medicines</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('expiryDateInput').value = today;
    
    // Initial check
    checkExpiry();
}

// Add Medicine Form
function showAddForm() {
    const form = `
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Add New Medicine</h4>
            </div>
            <div class="card-body">
                <form id="addMedicineForm">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="medicineName" class="form-label fw-medium">
                                    <i class="fas fa-pills me-2"></i>Medicine Name
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-capsules"></i>
                                    </span>
                                    <input type="text" class="form-control form-control-lg" id="medicineName" 
                                           placeholder="e.g., Paracetamol 500mg" required>
                                </div>
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="quantity" class="form-label fw-medium">
                                    <i class="fas fa-boxes me-2"></i>Quantity
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-hashtag"></i>
                                    </span>
                                    <input type="number" class="form-control form-control-lg" id="quantity" 
                                           min="1" value="1" required>
                                </div>
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="expiryDate" class="form-label fw-medium">
                                    <i class="far fa-calendar-alt me-2"></i>Expiry Date
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="far fa-calendar"></i>
                                    </span>
                                    <input type="date" class="form-control form-control-lg" id="expiryDate" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="manufacturer" class="form-label fw-medium">
                                    <i class="fas fa-industry me-2"></i>Manufacturer
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-building"></i>
                                    </span>
                                    <input type="text" class="form-control form-control-lg" id="manufacturer" 
                                           placeholder="e.g., ABC Pharmaceuticals" required>
                                </div>
                            </div>
                            
                            <div class="form-group mb-4">
                                <label for="price" class="form-label fw-medium">
                                    <i class="fas fa-tag me-2"></i>Price (per unit)
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-rupee-sign"></i>
                                    </span>
                                    <input type="number" step="0.01" min="0" class="form-control form-control-lg" 
                                           id="price" placeholder="0.00" required>
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="button" class="btn btn-outline-secondary me-md-2" 
                                        onclick="showSection('display')">
                                    <i class="fas fa-times me-1"></i> Cancel
                                </button>
                                <button type="submit" class="btn btn-primary" id="saveMedicineBtn">
                                    <i class="fas fa-save me-1"></i> Save Medicine
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div id="formLoading" class="text-center my-4" style="display: none;">
                        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                            <span class="visually-hidden">Saving...</span>
                        </div>
                        <p class="mt-3 text-muted fs-5">Saving medicine details...</p>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.getElementById('content-area').innerHTML = form;
    
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('expiryDate').min = today;
    
    // Add form submission handler
    document.getElementById('addMedicineForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const form = e.target;
        const saveButton = document.getElementById('saveMedicineBtn');
        const formLoading = document.getElementById('formLoading');
        
        try {
            // Show loading state
            saveButton.disabled = true;
            formLoading.style.display = 'block';
            
            // Simulate save delay (1.5s)
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Create medicine object
            const medicine = {
                name: document.getElementById('medicineName').value.trim(),
                quantity: parseInt(document.getElementById('quantity').value),
                expiryDate: document.getElementById('expiryDate').value,
                manufacturer: document.getElementById('manufacturer').value.trim(),
                price: parseFloat(document.getElementById('price').value),
                addedDate: new Date().toISOString().split('T')[0]
            };
            
            // Add to medicines array
            medicines.push(medicine);
            
            // Save to localStorage
            localStorage.setItem('medicines', JSON.stringify(medicines));
            
            // Show success message
            showError('Medicine added successfully!', true);
            
            // Return to medicine list after a short delay
            setTimeout(() => showSection('display'), 1000);
            
        } catch (error) {
            console.error('Error saving medicine:', error);
            showError('An error occurred while saving the medicine');
        } finally {
            // Hide loading state
            saveButton.disabled = false;
            formLoading.style.display = 'none';
        }
    });
}

// Search Medicine Form
function showSearchForm() {
    const form = `
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fas fa-search me-2"></i>Search Medicine</h4>
            </div>
            <div class="card-body">
                <form id="searchForm" onsubmit="event.preventDefault(); searchMedicine(this);">
                    <div class="mb-3">
                        <label for="searchTerm" class="form-label">Search by Name, Manufacturer, or Expiry Date</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-pills"></i></span>
                            <input type="text" class="form-control form-control-lg" id="searchTerm" 
                                   placeholder="Enter medicine name, manufacturer, etc." required>
                        </div>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg" id="searchButton">
                            <i class="fas fa-search me-2"></i>Search Medicine
                        </button>
                    </div>
                    <div id="searchLoading" class="text-center my-4" style="display: none;">
                        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                            <span class="visually-hidden">Searching...</span>
                        </div>
                        <p class="mt-3 text-muted fs-5">Searching medicines...</p>
                    </div>
                    <div id="searchResults" class="mt-4"></div>
                </form>
            </div>
        </div>`;
    
    document.getElementById('content-area').innerHTML = form;
    document.getElementById('searchForm').addEventListener('submit', (e) => searchMedicine(e));
}

// Search Medicine Function
async function searchMedicine(form) {
    const searchTerm = document.getElementById('searchTerm').value.trim().toLowerCase();
    const searchButton = document.getElementById('searchButton');
    const searchLoading = document.getElementById('searchLoading');
    const searchResults = document.getElementById('searchResults');
    
    if (!searchTerm) {
        showError('Please enter a search term');
        return;
    }
    
    try {
        // Show loading state
        searchButton.disabled = true;
        searchLoading.style.display = 'block';
        searchResults.innerHTML = '';
        
        // Simulate search delay (1.5s)
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Perform search
        const results = medicines.filter(medicine => 
            medicine.name.toLowerCase().includes(searchTerm) ||
            (medicine.manufacturer && medicine.manufacturer.toLowerCase().includes(searchTerm)) ||
            (medicine.expiryDate && medicine.expiryDate.toLowerCase().includes(searchTerm))
        );
        
        // Display results
        if (results.length === 0) {
            searchResults.innerHTML = `
                <div class="alert alert-info mt-4" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    No medicines found matching "${searchTerm}"
                </div>`;
        } else {
            searchResults.innerHTML = `
                <div class="card mt-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Search Results (${results.length})</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Manufacturer</th>
                                        <th>Quantity</th>
                                        <th>Expiry Date</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${results.map(medicine => `
                                        <tr>
                                            <td>${escapeHtml(medicine.name)}</td>
                                            <td>${medicine.manufacturer ? escapeHtml(medicine.manufacturer) : '-'}</td>
                                            <td>${medicine.quantity}</td>
                                            <td>${medicine.expiryDate || '-'}</td>
                                            <td>${medicine.price ? `₹${parseFloat(medicine.price).toFixed(2)}` : '-'}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>`;
        }
    } catch (error) {
        console.error('Search error:', error);
        showError('An error occurred while searching');
    } finally {
        // Hide loading state
        searchButton.disabled = false;
        searchLoading.style.display = 'none';
    }
}

// Helper function to escape HTML
function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .toString()
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// Edit Medicine Form
function showEditForm() {
    const html = `
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Medicine</h4>
            </div>
            <div class="card-body">
                <div class="search-box mb-4">
                    <div class="input-group input-group-lg">
                        <span class="input-group-text bg-white">
                            <i class="fas fa-search text-muted"></i>
                        </span>
                        <input type="text" class="form-control form-control-lg" id="editSearch" 
                               placeholder="Search medicine to edit..." autofocus>
                    </div>
                    <div class="form-text text-muted ms-2">
                        Start typing to search for a medicine to edit
                    </div>
                </div>
                
                <div id="searchResults" class="mt-4">
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-search fa-3x mb-3"></i>
                        <p class="mb-0">Search for a medicine to edit</p>
                    </div>
                </div>
                
                <div id="editFormContainer" class="mt-4" style="display: none;">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0">Edit Medicine Details</h5>
                        <button type="button" class="btn btn-sm btn-outline-secondary" 
                                onclick="document.getElementById('editFormContainer').style.display = 'none'; document.getElementById('editSearch').value = ''; document.getElementById('searchResults').style.display = 'block';">
                            <i class="fas fa-arrow-left me-1"></i> Back to Search
                        </button>
                    </div>
                    <div id="editForm"></div>
                </div>
                
                <div id="editLoading" class="text-center my-5" style="display: none;">
                    <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3 text-muted">Loading medicine details...</p>
                </div>
            </div>
        </div>`;
    
    document.getElementById('content-area').innerHTML = html;
    
    // Add search functionality
    const editSearch = document.getElementById('editSearch');
    const searchResults = document.getElementById('searchResults');
    const editFormContainer = document.getElementById('editFormContainer');
    const editLoading = document.getElementById('editLoading');
    
    editSearch.addEventListener('input', function() {
        const searchTerm = this.value.trim().toLowerCase();
        
        if (searchTerm.length < 2) {
            searchResults.innerHTML = `
                <div class="text-center text-muted py-5">
                    <i class="fas fa-search fa-3x mb-3"></i>
                    <p class="mb-0">Type at least 2 characters to search</p>
                </div>`;
            return;
        }
        
        // Show loading
        searchResults.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Searching...</span>
                </div>
                <p class="mt-2 text-muted">Searching medicines...</p>
            </div>`;
        
        // Simulate search delay
        setTimeout(() => {
            const results = medicines.filter(med => 
                med.name.toLowerCase().includes(searchTerm) ||
                (med.manufacturer && med.manufacturer.toLowerCase().includes(searchTerm))
            );
            
            displayEditOptions(results);
        }, 500);
    });
}

// Load medicine data into the edit form
async function loadMedicineForEdit(medicineName) {
    const editFormContainer = document.getElementById('editFormContainer');
    const searchResults = document.getElementById('searchResults');
    const editLoading = document.getElementById('editLoading');
    
    try {
        // Show loading
        editLoading.style.display = 'block';
        searchResults.style.display = 'none';
        
        // Simulate loading delay
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Find the medicine
        const medicine = medicines.find(m => m.name === medicineName);
        if (!medicine) {
            throw new Error('Medicine not found');
        }
        
        // Create edit form
        const editForm = `
            <form id="editMedicineForm" onsubmit="event.preventDefault(); saveEditedMedicine('${escapeHtml(medicineName)}');">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label for="editName" class="form-label fw-medium">
                                <i class="fas fa-pills me-2"></i>Medicine Name
                            </label>
                            <input type="text" class="form-control form-control-lg" id="editName" 
                                   value="${escapeHtml(medicine.name)}" required>
                        </div>
                        
                        <div class="form-group mb-3">
                            <label for="editQuantity" class="form-label fw-medium">
                                <i class="fas fa-boxes me-2"></i>Quantity
                            </label>
                            <input type="number" class="form-control form-control-lg" id="editQuantity" 
                                   value="${medicine.quantity}" min="1" required>
                        </div>
                        
                        <div class="form-group mb-3">
                            <label for="editExpiryDate" class="form-label fw-medium">
                                <i class="far fa-calendar-alt me-2"></i>Expiry Date
                            </label>
                            <input type="date" class="form-control form-control-lg" id="editExpiryDate" 
                                   value="${medicine.expiryDate || ''}">
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label for="editManufacturer" class="form-label fw-medium">
                                <i class="fas fa-industry me-2"></i>Manufacturer
                            </label>
                            <input type="text" class="form-control form-control-lg" id="editManufacturer" 
                                   value="${medicine.manufacturer ? escapeHtml(medicine.manufacturer) : ''}">
                        </div>
                        
                        <div class="form-group mb-4">
                            <label for="editPrice" class="form-label fw-medium">
                                <i class="fas fa-tag me-2"></i>Price (per unit)
                            </label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="fas fa-rupee-sign"></i>
                                </span>
                                <input type="number" step="0.01" min="0" class="form-control form-control-lg" 
                                       id="editPrice" value="${medicine.price || '0.00'}">
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <button type="button" class="btn btn-outline-danger me-2" 
                                    onclick="if(confirm('Are you sure you want to delete this medicine?')) deleteMedicine('${escapeHtml(medicineName)}')">
                                <i class="fas fa-trash-alt me-1"></i> Delete
                            </button>
                            <button type="submit" class="btn btn-primary" id="saveEditBtn">
                                <i class="fas fa-save me-1"></i> Save Changes
                            </button>
                        </div>
                    </div>
                </div>
                
                <div id="editFormLoading" class="text-center my-4" style="display: none;">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Saving...</span>
                    </div>
                    <p class="mt-2 text-muted">Saving changes...</p>
                </div>
            </form>`;
        
        // Update the DOM
        document.getElementById('editForm').innerHTML = editForm;
        editFormContainer.style.display = 'block';
        
        // Set minimum date to today for expiry date
        const today = new Date().toISOString().split('T')[0];
        const expiryDateInput = document.getElementById('editExpiryDate');
        if (expiryDateInput) {
            expiryDateInput.min = today;
        }
        
    } catch (error) {
        console.error('Error loading medicine for edit:', error);
        showError('Failed to load medicine details');
        // Show search results again
        searchResults.style.display = 'block';
    } finally {
        editLoading.style.display = 'none';
    }
}

// Save edited medicine
async function saveEditedMedicine(oldName) {
    const saveButton = document.getElementById('saveEditBtn');
    const formLoading = document.getElementById('editFormLoading');
    
    try {
        // Show loading
        saveButton.disabled = true;
        formLoading.style.display = 'block';
        
        // Simulate save delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Get form values
        const updatedMedicine = {
            name: document.getElementById('editName').value.trim(),
            quantity: parseInt(document.getElementById('editQuantity').value),
            expiryDate: document.getElementById('editExpiryDate').value || null,
            manufacturer: document.getElementById('editManufacturer').value.trim() || null,
            price: parseFloat(document.getElementById('editPrice').value) || 0,
            addedDate: new Date().toISOString().split('T')[0]
        };
        
        // Find and update the medicine
        const index = medicines.findIndex(m => m.name === oldName);
        if (index === -1) {
            throw new Error('Medicine not found');
        }
        
        // Update the medicine
        medicines[index] = updatedMedicine;
        
        // Save to localStorage
        localStorage.setItem('medicines', JSON.stringify(medicines));
        
        // Show success message
        showError('Medicine updated successfully!', true);
        
        // Return to medicine list after a short delay
        setTimeout(() => showSection('display'), 1000);
        
    } catch (error) {
        console.error('Error saving medicine:', error);
        showError('An error occurred while saving the medicine');
    } finally {
        saveButton.disabled = false;
        formLoading.style.display = 'none';
    }
}

// Delete medicine
async function deleteMedicine(medicineName) {
    if (!confirm(`Are you sure you want to delete "${medicineName}"? This action cannot be undone.`)) {
        return;
    }
    
    try {
        // Show loading
        const deleteButton = event.target.closest('button');
        const originalContent = deleteButton.innerHTML;
        deleteButton.disabled = true;
        deleteButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Deleting...';
        
        // Simulate delete delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Remove the medicine
        const index = medicines.findIndex(m => m.name === medicineName);
        if (index !== -1) {
            medicines.splice(index, 1);
            localStorage.setItem('medicines', JSON.stringify(medicines));
            showError('Medicine deleted successfully!', true);
            
            // Return to medicine list after a short delay
            setTimeout(() => showSection('display'), 800);
        }
        
    } catch (error) {
        console.error('Error deleting medicine:', error);
        showError('An error occurred while deleting the medicine');
    }
}

// Display search results for editing
function displayEditOptions(results) {
    const searchResults = document.getElementById('searchResults');
    
    if (!results || results.length === 0) {
        searchResults.innerHTML = `
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                No medicines found matching your search.
            </div>`;
        return;
    }
    
    let html = `
        <div class="list-group">
            ${results.map(med => `
                <div class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">${escapeHtml(med.name)}</h6>
                            <small class="text-muted">
                                ${med.manufacturer ? escapeHtml(med.manufacturer) : 'No manufacturer'}
                                ${med.expiryDate ? `• Expires: ${med.expiryDate}` : ''}
                            </small>
                        </div>
                        <div>
                            <span class="badge bg-primary rounded-pill me-2">Qty: ${med.quantity}</span>
                            <button class="btn btn-sm btn-outline-primary" 
                                    onclick="loadMedicineForEdit('${escapeHtml(med.name)}')">
                                <i class="fas fa-edit me-1"></i> Edit
                            </button>
                        </div>
                    </div>
                </div>
            `).join('')}
        </div>`;
    
    searchResults.innerHTML = html;
}

// Check Low Stock
function checkLowStock() {
    const threshold = parseInt(document.getElementById('lowStockThreshold').value) || 0;
    const lowStockMedicines = medicines.filter(medicine => medicine.quantity <= threshold);
    const lowStockList = document.getElementById('lowStockList');
    
    if (lowStockMedicines.length === 0) {
        lowStockList.innerHTML = `
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                All medicines have quantity greater than ${threshold}.
            </div>
        `;
    } else {
        displayMedicines(lowStockMedicines, 'lowStockList');
    }
}

// Check Expiry
function checkExpiry() {
    const expiryDateInput = document.getElementById('expiryDateInput');
    if (!expiryDateInput) return;
    
    const expiryDate = new Date(expiryDateInput.value);
    if (isNaN(expiryDate.getTime())) {
        showError('Please enter a valid date');
        return;
    }
    
    const expiringMedicines = medicines.filter(medicine => {
        const medExpiryDate = new Date(medicine.expiryDate);
        return medExpiryDate <= expiryDate;
    });
    
    const expiryList = document.getElementById('expiryList');
    if (!expiryList) return;
    
    if (expiringMedicines.length === 0) {
        expiryList.innerHTML = `
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                No medicines found expiring before ${expiryDate.toDateString()}.
            </div>
        `;
    } else {
        // Add a header showing the expiry threshold
        const header = document.createElement('div');
        header.className = 'mb-3';
        header.innerHTML = `
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Found ${expiringMedicines.length} medicines expiring before ${expiryDate.toDateString()}
            </div>
        `;
        
        // Clear existing content and add the header
        expiryList.innerHTML = '';
        expiryList.appendChild(header);
        
        // Display the medicines
        displayMedicines(expiringMedicines, 'expiryList');
    }
}

function displayExpiryResults(results) {
    const container = $('#expiryResults');
    container.empty();
    
    if (results.length === 0) {
        container.html('<div class="alert alert-info">No medicines expiring within the specified period.</div>');
        return;
    }
    
    container.html(results.map(med => `
        <div class="medicine-item">
            <h5>${med.name}</h5>
            <p>Expiry: ${med.expiryDate} <span class="badge bg-warning">Expiring Soon</span></p>
            <p>Manufacturer: ${med.manufacturer}</p>
            <p>Price: ₹${med.price.toFixed(2)}</p>
        </div>
    `).join(''));
}

// Save medicines to file
function saveMedicines() {
    // Save to localStorage
    localStorage.setItem('medicines', JSON.stringify(medicines));
    
    // Also save to medicines.txt
    const data = medicines.map(med => 
        `${med.name},${med.quantity},${med.expiryDate},${med.manufacturer},${med.price.toFixed(2)}
    `).join('');
    
    const blob = new Blob([data], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'medicines.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

// Clear cache function
function clearCache() {
    if (confirm('Are you sure you want to clear the cache? This will remove all saved medicines data.')) {
        // Clear localStorage
        localStorage.removeItem('medicines');
        
        // Show success message
        const successDiv = document.createElement('div');
        successDiv.className = 'alert alert-success';
        successDiv.innerHTML = `
            <h5 class="mb-3">Cache Cleared</h5>
            <p class="mb-0">The cache has been cleared. Please refresh the page to load the medicines again.</p>
        `;
        document.getElementById('content-area').innerHTML = '';
        document.getElementById('content-area').appendChild(successDiv);
        
        // Refresh page after 2 seconds
        setTimeout(() => {
            location.reload();
        }, 2000);
    }
}
